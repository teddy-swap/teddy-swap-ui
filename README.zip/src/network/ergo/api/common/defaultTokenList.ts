import { getDefaultTokenList } from '../../../../common/services/DefaultTokenList';

export const defaultTokenList$ = getDefaultTokenList('ergo');
