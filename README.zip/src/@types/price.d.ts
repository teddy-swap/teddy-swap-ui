type Ratio = {
  xPerY: number;
  yPerX: number;
};
