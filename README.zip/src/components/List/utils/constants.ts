export const BASE_GUTTER = 4;
