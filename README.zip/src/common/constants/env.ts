export const LANDING_URL = 'https://ergodex.io';
