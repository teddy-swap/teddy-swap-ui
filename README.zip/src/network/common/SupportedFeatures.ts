import { WalletSupportedFeatures } from './Wallet';

export type SupportedFeatures = WalletSupportedFeatures;
