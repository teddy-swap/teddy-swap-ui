export const DEFAULT_MINER_FEE = BigInt(2_000_000);
export const ERG_DECIMALS = 9;

export const MIN_EX_FEE = BigInt(7_000_000);
export const MIN_NITRO = 1.2;

export const UI_FEE = 1200000;
export const UI_FEE_BIGINT = 1200000n;
