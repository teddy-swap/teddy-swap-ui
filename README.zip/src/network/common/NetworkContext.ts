export interface NetworkContext {
  readonly height: number;
  readonly lastBlockId: number;
}
