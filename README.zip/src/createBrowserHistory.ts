import { createBrowserHistory } from 'history';

export const globalHistory = createBrowserHistory();
