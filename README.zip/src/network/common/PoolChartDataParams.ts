export interface PoolChartDataParams {
  from?: number;
  to?: number;
  resolution?: number;
}
