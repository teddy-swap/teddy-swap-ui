import styled from 'styled-components';

import { ConnectWalletButton } from '../../../../ConnectWalletButton/ConnectWalletButton';

export const HeaderConnectWalletButton = styled(ConnectWalletButton)`
  width: 175px;
`;
