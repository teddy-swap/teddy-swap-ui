import { Currency } from '../../../common/models/Currency';
import { networkAsset } from '../api/networkAsset/networkAsset';

export const depositAda = new Currency('2', networkAsset);
