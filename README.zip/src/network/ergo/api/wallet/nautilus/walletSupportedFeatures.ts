import { WalletSupportedFeatures } from '../../../../common/Wallet';

export const walletSupportedFeatures: WalletSupportedFeatures = {
  createPool: true,
};
