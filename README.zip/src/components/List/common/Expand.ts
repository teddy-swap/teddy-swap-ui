export interface Expand {
  readonly height: number;
  readonly accordion?: boolean;
}
