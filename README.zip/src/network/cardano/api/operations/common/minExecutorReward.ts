export const minExecutorReward = 1000000n;
